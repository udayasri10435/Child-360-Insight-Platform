import express from 'express';
import { createServer as createViteServer } from 'vite';
import path from 'path';
import { fileURLToPath } from 'url';
import dotenv from 'dotenv';
import { GoogleGenAI } from '@google/genai';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // --- Simulated Microservices Ecosystem ---

  // 1. Identity & Auth Service (Simulated)
  const identityService = express.Router();
  identityService.get('/health', (req, res) => res.json({ status: 'UP', language: 'Kotlin' }));
  app.use('/api/v1/identity', identityService);

  // 2. Academic Service (Simulated)
  const academicService = express.Router();
  academicService.get('/health', (req, res) => res.json({ status: 'UP', language: 'Go' }));
  
  academicService.post('/apply-curve', (req, res) => {
    const { scores, curveType, config } = req.body;
    
    if (!scores || !Array.isArray(scores)) {
      return res.status(400).json({ error: 'Invalid scores array' });
    }

    let curvedScores = [];

    if (curveType === 'fixed') {
      // Fixed thresholds (e.g., { "A": 90, "B": 80, ... })
      const thresholds = config.thresholds;
      curvedScores = scores.map(score => {
        const percentage = (score.value / score.max) * 100;
        let grade = 'F';
        const sortedGrades = Object.keys(thresholds).sort((a, b) => thresholds[b] - thresholds[a]);
        for (const g of sortedGrades) {
          if (percentage >= thresholds[g]) {
            grade = g;
            break;
          }
        }
        return { ...score, curvedGrade: grade };
      });
    } else if (curveType === 'bell') {
      // Simple Bell Curve (Shift mean to targetMean)
      const targetMean = config.targetMean || 75;
      const currentMean = scores.reduce((acc, s) => acc + (s.value / s.max) * 100, 0) / scores.length;
      const shift = targetMean - currentMean;
      
      curvedScores = scores.map(score => {
        const percentage = (score.value / score.max) * 100;
        const curvedPercentage = Math.min(100, Math.max(0, percentage + shift));
        return { ...score, curvedPercentage };
      });
    } else {
      return res.status(400).json({ error: 'Unsupported curve type' });
    }

    res.json({ curvedScores });
  });

  app.use('/api/v1/academic', academicService);

  // 3. Health Service (Simulated)
  const healthService = express.Router();
  healthService.get('/health', (req, res) => res.json({ status: 'UP', language: 'Rust' }));
  app.use('/api/v1/health', healthService);

  // 4. Analytics Service (Simulated)
  const analyticsService = express.Router();
  analyticsService.get('/health', (req, res) => res.json({ status: 'UP', language: 'Python' }));
  
  // AI Insight Generation Endpoint
  analyticsService.post('/generate-insight', async (req, res) => {
    const { academicData, healthData, childName } = req.body;
    
    if (!process.env.GEMINI_API_KEY) {
      return res.status(500).json({ error: 'GEMINI_API_KEY is not configured' });
    }

    try {
      const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });

      const prompt = `
        You are the "Child 360° Insight Platform" AI Analyst.
        Analyze the following data for a child named ${childName} and provide a professional, 
        insightful correlation report in Markdown format.
        
        Academic Data: ${JSON.stringify(academicData)}
        Health Data: ${JSON.stringify(healthData)}
        
        Focus on:
        1. Academic trends.
        2. Health status.
        3. Potential correlations (e.g., does poor sleep affect math scores?).
        4. Actionable recommendations for parents.
        
        Keep it concise but deep.
      `;

      const result = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: prompt
      });
      res.json({ insight: result.text });
    } catch (error) {
      console.error('AI Insight Error:', error);
      res.status(500).json({ error: 'Failed to generate insight' });
    }
  });
  app.use('/api/v1/analytics', analyticsService);

  // 1000th Service: The Everything Saver (Simulated)
  const everythingSaver = express.Router();
  everythingSaver.get('/health', (req, res) => res.json({ status: 'UP', language: 'Malbolge', message: 'Job security guaranteed.' }));
  app.use('/api/v1/everything-saver', everythingSaver);

  // --- Vite Middleware ---
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Child 360° Insight Platform running at http://localhost:${PORT}`);
  });
}

startServer();
