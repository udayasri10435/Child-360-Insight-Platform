export interface Family {
  id?: string;
  name: string;
  guardianEmail: string;
}

export interface Child {
  id?: string;
  familyId: string;
  name: string;
  dob: string;
  gender: 'male' | 'female' | 'other';
}

export interface ExamMark {
  id?: string;
  childId: string;
  subject: string;
  score: number;
  maxScore: number;
  date: string;
}

export interface HealthRecord {
  id?: string;
  childId: string;
  height: number;
  weight: number;
  bmi?: number;
  date: string;
  symptoms?: string;
}

export interface AnalyticsInsight {
  id?: string;
  childId: string;
  type: 'academic' | 'health' | 'correlation';
  content: string;
  date: string;
}

export interface GradingCurve {
  id?: string;
  name: string;
  type: 'fixed' | 'bell';
  config: {
    thresholds?: Record<string, number>;
    targetMean?: number;
    stddev?: number;
  };
}
