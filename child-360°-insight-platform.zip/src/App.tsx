import React, { useState, useEffect, createContext, useContext } from 'react';
import { 
  collection, 
  query, 
  where, 
  onSnapshot, 
  addDoc, 
  getDocs, 
  doc, 
  getDoc, 
  updateDoc,
  orderBy, 
  limit,
  getDocFromServer
} from 'firebase/firestore';
import { 
  signInWithPopup, 
  GoogleAuthProvider, 
  signOut, 
  onAuthStateChanged, 
  User 
} from 'firebase/auth';
import { db, auth } from './firebase';
import { 
  LayoutDashboard, 
  Users, 
  Activity, 
  GraduationCap, 
  BrainCircuit, 
  Plus, 
  LogOut, 
  LogIn, 
  ChevronRight, 
  TrendingUp, 
  Heart, 
  AlertCircle,
  Microscope,
  Database,
  Terminal,
  Cpu
} from 'lucide-react';
import { 
  LineChart, 
  Line, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer, 
  AreaChart, 
  Area 
} from 'recharts';
import ReactMarkdown from 'react-markdown';
import { motion, AnimatePresence } from 'motion/react';
import { Child, Family, ExamMark, HealthRecord, AnalyticsInsight, GradingCurve } from './types';

// --- Contexts ---
const AuthContext = createContext<{ user: User | null; loading: boolean }>({ user: null, loading: true });

// --- Firestore Error Handling ---
enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId: string | undefined;
    email: string | null | undefined;
    emailVerified: boolean | undefined;
    isAnonymous: boolean | undefined;
    tenantId: string | null | undefined;
    providerInfo: {
      providerId: string;
      displayName: string | null;
      email: string | null;
      photoUrl: string | null;
    }[];
  }
}

function handleFirestoreError(error: unknown, operationType: OperationType, path: string | null) {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: auth.currentUser?.uid,
      email: auth.currentUser?.email,
      emailVerified: auth.currentUser?.emailVerified,
      isAnonymous: auth.currentUser?.isAnonymous,
      tenantId: auth.currentUser?.tenantId,
      providerInfo: auth.currentUser?.providerData.map(provider => ({
        providerId: provider.providerId,
        displayName: provider.displayName,
        email: provider.email,
        photoUrl: provider.photoURL
      })) || []
    },
    operationType,
    path
  }
  console.error('Firestore Error: ', JSON.stringify(errInfo));
  throw new Error(JSON.stringify(errInfo));
}

// --- Components ---

const SidebarItem = ({ icon: Icon, label, active, onClick, language }: { icon: any, label: string, active?: boolean, onClick: () => void, language?: string }) => (
  <button 
    onClick={onClick}
    className={`w-full flex items-center justify-between p-3 transition-colors group ${active ? 'bg-black text-white' : 'hover:bg-gray-100 text-gray-600'}`}
  >
    <div className="flex items-center gap-3">
      <Icon size={18} className={active ? 'text-white' : 'text-gray-400 group-hover:text-black'} />
      <span className="text-xs font-mono tracking-tight uppercase">{label}</span>
    </div>
    {language && <span className="text-[10px] font-mono opacity-40 italic">{language}</span>}
  </button>
);

const StatCard = ({ label, value, icon: Icon, trend }: { label: string, value: string | number, icon: any, trend?: string }) => (
  <div className="border border-black p-4 bg-white flex flex-col gap-2">
    <div className="flex justify-between items-start">
      <span className="text-[10px] font-mono uppercase tracking-widest text-gray-400">{label}</span>
      <Icon size={14} className="text-gray-400" />
    </div>
    <div className="text-2xl font-mono tracking-tighter">{value}</div>
    {trend && <div className="text-[10px] font-mono text-green-600">↑ {trend}</div>}
  </div>
);

const ServiceStatus = ({ name, language, status }: { name: string, language: string, status: string }) => (
  <div className="flex items-center justify-between p-2 border-b border-gray-100 last:border-0">
    <div className="flex flex-col">
      <span className="text-[10px] font-mono uppercase">{name}</span>
      <span className="text-[9px] text-gray-400 font-mono italic">{language}</span>
    </div>
    <div className="flex items-center gap-2">
      <div className={`w-1.5 h-1.5 rounded-full ${status === 'UP' ? 'bg-green-500' : 'bg-red-500'}`} />
      <span className="text-[10px] font-mono text-gray-400">{status}</span>
    </div>
  </div>
);

// --- Error Boundary ---
export class ErrorBoundary extends React.Component<{ children: React.ReactNode }, { hasError: boolean, error: any }> {
  constructor(props: any) {
    super(props);
    this.state = { hasError: false, error: null };
  }

  static getDerivedStateFromError(error: any) {
    return { hasError: true, error };
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="h-screen w-screen flex items-center justify-center bg-red-50 p-12 font-mono">
          <div className="max-w-2xl border border-red-500 p-8 bg-white shadow-[8px_8px_0px_0px_rgba(239,68,68,1)]">
            <div className="flex items-center gap-3 text-red-600 mb-4">
              <AlertCircle size={24} />
              <h1 className="text-lg font-bold uppercase tracking-tighter">System Fault Detected</h1>
            </div>
            <p className="text-xs text-gray-600 mb-6 uppercase tracking-widest leading-relaxed">
              One of the 1,000 microservices has encountered a fatal exception. 
              The service mesh is attempting to isolate the failure.
            </p>
            <div className="bg-gray-900 text-green-400 p-4 text-[10px] overflow-auto max-h-64 font-mono">
              <pre>{JSON.stringify(this.state.error, null, 2)}</pre>
            </div>
            <button 
              onClick={() => window.location.reload()}
              className="mt-6 w-full border border-black p-3 text-[10px] uppercase tracking-widest hover:bg-black hover:text-white transition-all"
            >
              Reboot Service Mesh
            </button>
          </div>
        </div>
      );
    }
    return this.props.children;
  }
}

// --- Grading Curve Modal ---
const GradingCurveModal = ({ curve, onSave, onCancel }: { curve: GradingCurve, onSave: (c: GradingCurve) => void, onCancel: () => void }) => {
  const [formData, setFormData] = useState<GradingCurve>({ ...curve });

  const handleThresholdChange = (grade: string, value: number) => {
    setFormData(prev => ({
      ...prev,
      config: {
        ...prev.config,
        thresholds: {
          ...(prev.config.thresholds || {}),
          [grade]: value
        }
      }
    }));
  };

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-6">
      <motion.div 
        initial={{ scale: 0.9, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        className="bg-white border border-black w-full max-w-lg shadow-[12px_12px_0px_0px_rgba(0,0,0,1)] flex flex-col"
      >
        <div className="p-6 border-b border-black bg-black text-white flex justify-between items-center">
          <h3 className="text-xs font-mono uppercase font-bold tracking-widest">Edit Grading Curve</h3>
          <button onClick={onCancel} className="hover:opacity-70"><Plus size={18} className="rotate-45" /></button>
        </div>
        
        <div className="p-8 flex flex-col gap-6 overflow-y-auto max-h-[70vh]">
          <div className="flex flex-col gap-2">
            <label className="text-[10px] font-mono uppercase text-gray-400">Curve Name</label>
            <input 
              type="text" 
              value={formData.name}
              onChange={(e) => setFormData({ ...formData, name: e.target.value })}
              className="border border-black p-3 font-mono text-xs focus:outline-none focus:bg-gray-50"
            />
          </div>

          <div className="flex flex-col gap-2">
            <label className="text-[10px] font-mono uppercase text-gray-400">Algorithm Type</label>
            <select 
              value={formData.type}
              onChange={(e) => setFormData({ ...formData, type: e.target.value as 'fixed' | 'bell' })}
              className="border border-black p-3 font-mono text-xs focus:outline-none focus:bg-gray-50"
            >
              <option value="fixed">Fixed Thresholds</option>
              <option value="bell">Bell Curve (Mean Shift)</option>
            </select>
          </div>

          {formData.type === 'fixed' && (
            <div className="flex flex-col gap-4">
              <label className="text-[10px] font-mono uppercase text-gray-400">Thresholds (%)</label>
              <div className="grid grid-cols-2 gap-4">
                {['A', 'B', 'C', 'D', 'F'].map(grade => (
                  <div key={grade} className="flex items-center gap-3">
                    <span className="text-xs font-mono font-bold w-4">{grade}</span>
                    <input 
                      type="number" 
                      value={formData.config.thresholds?.[grade] || 0}
                      onChange={(e) => handleThresholdChange(grade, parseInt(e.target.value))}
                      className="flex-1 border border-black p-2 font-mono text-xs focus:outline-none"
                    />
                  </div>
                ))}
              </div>
            </div>
          )}

          {formData.type === 'bell' && (
            <div className="grid grid-cols-2 gap-4">
              <div className="flex flex-col gap-2">
                <label className="text-[10px] font-mono uppercase text-gray-400">Target Mean (%)</label>
                <input 
                  type="number" 
                  value={formData.config.targetMean || 0}
                  onChange={(e) => setFormData({ ...formData, config: { ...formData.config, targetMean: parseInt(e.target.value) } })}
                  className="border border-black p-3 font-mono text-xs focus:outline-none"
                />
              </div>
              <div className="flex flex-col gap-2">
                <label className="text-[10px] font-mono uppercase text-gray-400">Target StdDev</label>
                <input 
                  type="number" 
                  value={formData.config.stddev || 0}
                  onChange={(e) => setFormData({ ...formData, config: { ...formData.config, stddev: parseInt(e.target.value) } })}
                  className="border border-black p-3 font-mono text-xs focus:outline-none"
                />
              </div>
            </div>
          )}
        </div>

        <div className="p-6 border-t border-black bg-gray-50 flex gap-4">
          <button 
            onClick={onCancel}
            className="flex-1 border border-black p-3 text-[10px] font-mono uppercase tracking-widest hover:bg-gray-100 transition-all"
          >
            Cancel
          </button>
          <button 
            onClick={() => onSave(formData)}
            className="flex-1 bg-black text-white p-3 text-[10px] font-mono uppercase tracking-widest hover:bg-gray-800 transition-all"
          >
            Save Configuration
          </button>
        </div>
      </motion.div>
    </div>
  );
};

export default function App() {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);
  const [isLoggingIn, setIsLoggingIn] = useState(false);
  const [authError, setAuthError] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState('dashboard');
  const [selectedChild, setSelectedChild] = useState<Child | null>(null);
  const [children, setChildren] = useState<Child[]>([]);
  const [family, setFamily] = useState<Family | null>(null);
  const [marks, setMarks] = useState<ExamMark[]>([]);
  const [health, setHealth] = useState<HealthRecord[]>([]);
  const [insights, setInsights] = useState<AnalyticsInsight[]>([]);
  const [gradingCurves, setGradingCurves] = useState<GradingCurve[]>([]);
  const [editingCurve, setEditingCurve] = useState<GradingCurve | null>(null);
  const [isGenerating, setIsGenerating] = useState(false);

  // Auth Listener
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (u) => {
      setUser(u);
      setLoading(false);
    });
    return unsubscribe;
  }, []);

  // Connection Test
  useEffect(() => {
    async function testConnection() {
      try {
        await getDocFromServer(doc(db, 'test', 'connection'));
      } catch (error) {
        if(error instanceof Error && error.message.includes('the client is offline')) {
          console.error("Please check your Firebase configuration.");
        }
      }
    }
    testConnection();
  }, []);

  // Data Listeners
  useEffect(() => {
    if (!user) return;

    // 1. Get Family
    const familyQuery = query(collection(db, 'families'), where('guardianEmail', '==', user.email));
    const unsubFamily = onSnapshot(familyQuery, (snap) => {
      if (!snap.empty) {
        const famDoc = snap.docs[0];
        setFamily({ id: famDoc.id, ...famDoc.data() } as Family);
      } else {
        // Create family if not exists
        addDoc(collection(db, 'families'), {
          name: user.displayName?.split(' ').pop() || 'Unknown',
          guardianEmail: user.email
        }).catch(e => handleFirestoreError(e, OperationType.CREATE, 'families'));
      }
    }, (e) => handleFirestoreError(e, OperationType.LIST, 'families'));

    // 2. Get Children
    const childrenQuery = query(collection(db, 'children'));
    const unsubChildren = onSnapshot(childrenQuery, (snap) => {
      const list = snap.docs.map(d => ({ id: d.id, ...d.data() } as Child));
      setChildren(list);
    }, (e) => handleFirestoreError(e, OperationType.LIST, 'children'));

    return () => {
      unsubFamily();
      unsubChildren();
    };
  }, [user]);

  // Child Data Listeners
  useEffect(() => {
    if (!selectedChild) return;

    const marksQuery = query(collection(db, 'exam_marks'), where('childId', '==', selectedChild.id), orderBy('date', 'asc'));
    const unsubMarks = onSnapshot(marksQuery, (snap) => {
      setMarks(snap.docs.map(d => ({ id: d.id, ...d.data() } as ExamMark)));
    }, (e) => handleFirestoreError(e, OperationType.LIST, 'exam_marks'));

    const healthQuery = query(collection(db, 'health_records'), where('childId', '==', selectedChild.id), orderBy('date', 'asc'));
    const unsubHealth = onSnapshot(healthQuery, (snap) => {
      setHealth(snap.docs.map(d => ({ id: d.id, ...d.data() } as HealthRecord)));
    }, (e) => handleFirestoreError(e, OperationType.LIST, 'health_records'));

    const insightsQuery = query(collection(db, 'analytics_insights'), where('childId', '==', selectedChild.id), orderBy('date', 'desc'));
    const unsubInsights = onSnapshot(insightsQuery, (snap) => {
      setInsights(snap.docs.map(d => ({ id: d.id, ...d.data() } as AnalyticsInsight)));
    }, (e) => handleFirestoreError(e, OperationType.LIST, 'analytics_insights'));

    const gradingCurvesQuery = query(collection(db, 'grading_curves'));
    const unsubGradingCurves = onSnapshot(gradingCurvesQuery, (snap) => {
      setGradingCurves(snap.docs.map(d => ({ id: d.id, ...d.data() } as GradingCurve)));
    }, (e) => handleFirestoreError(e, OperationType.LIST, 'grading_curves'));

    return () => {
      unsubMarks();
      unsubHealth();
      unsubInsights();
      unsubGradingCurves();
    };
  }, [selectedChild]);

  const handleLogin = async () => {
    if (isLoggingIn) return;
    setIsLoggingIn(true);
    setAuthError(null);
    const provider = new GoogleAuthProvider();
    try {
      await signInWithPopup(auth, provider);
    } catch (error: any) {
      console.error('Login Error:', error);
      if (error.code === 'auth/popup-blocked') {
        setAuthError('Popup blocked by browser. Please allow popups for this site and try again.');
      } else if (error.code === 'auth/cancelled-popup-request') {
        setAuthError('Login request was cancelled. Please try again.');
      } else if (error.code === 'auth/popup-closed-by-user') {
        setAuthError('Login window was closed before completion.');
      } else {
        setAuthError('An unexpected authentication error occurred.');
      }
    } finally {
      setIsLoggingIn(false);
    }
  };

  const handleLogout = () => signOut(auth);

  const generateAIInsight = async () => {
    if (!selectedChild) return;
    setIsGenerating(true);
    try {
      const response = await fetch('/api/v1/analytics/generate-insight', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          childName: selectedChild.name,
          academicData: marks.slice(-5),
          healthData: health.slice(-5)
        })
      });
      const data = await response.json();
      if (data.insight) {
        await addDoc(collection(db, 'analytics_insights'), {
          childId: selectedChild.id,
          type: 'correlation',
          content: data.insight,
          date: new Date().toISOString()
        }).catch(e => handleFirestoreError(e, OperationType.CREATE, 'analytics_insights'));
      }
    } catch (error) {
      console.error('Insight Generation Error:', error);
    } finally {
      setIsGenerating(false);
    }
  };

  const saveCurve = async (curve: GradingCurve) => {
    if (!curve.id) return;
    try {
      const curveRef = doc(db, 'grading_curves', curve.id);
      const { id, ...data } = curve;
      await updateDoc(curveRef, data as any);
      setEditingCurve(null);
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, `grading_curves/${curve.id}`);
    }
  };

  const seedData = async () => {
    if (!user) return;
    
    // 1. Create Family
    const familyRef = await addDoc(collection(db, 'families'), {
      name: 'Madrigal',
      guardianEmail: user.email
    }).catch(e => handleFirestoreError(e, OperationType.CREATE, 'families'));

    if (!familyRef) return;

    // 2. Create Child
    const childRef = await addDoc(collection(db, 'children'), {
      familyId: familyRef.id,
      name: 'Mirabel Madrigal',
      dob: '2015-05-15T00:00:00.000Z',
      gender: 'female'
    }).catch(e => handleFirestoreError(e, OperationType.CREATE, 'children'));

    if (!childRef) return;

    // 3. Create Exam Marks
    const subjects = ['Mathematics', 'Science', 'History', 'Language Arts'];
    for (let i = 0; i < 10; i++) {
      await addDoc(collection(db, 'exam_marks'), {
        childId: childRef.id,
        subject: subjects[Math.floor(Math.random() * subjects.length)],
        score: 70 + Math.floor(Math.random() * 30),
        maxScore: 100,
        date: new Date(Date.now() - (10 - i) * 7 * 24 * 60 * 60 * 1000).toISOString()
      }).catch(e => handleFirestoreError(e, OperationType.CREATE, 'exam_marks'));
    }

    // 4. Create Health Records
    for (let i = 0; i < 10; i++) {
      await addDoc(collection(db, 'health_records'), {
        childId: childRef.id,
        height: 120 + i * 0.5,
        weight: 25 + i * 0.8,
        bmi: 18 + Math.random() * 2,
        date: new Date(Date.now() - (10 - i) * 7 * 24 * 60 * 60 * 1000).toISOString(),
        symptoms: i === 5 ? 'Mild fever reported' : ''
      }).catch(e => handleFirestoreError(e, OperationType.CREATE, 'health_records'));
    }

    // 5. Create Grading Curves
    await addDoc(collection(db, 'grading_curves'), {
      name: 'Standard Fixed Thresholds',
      type: 'fixed',
      config: { thresholds: { 'A': 90, 'B': 80, 'C': 70, 'D': 60, 'F': 0 } }
    }).catch(e => handleFirestoreError(e, OperationType.CREATE, 'grading_curves'));

    await addDoc(collection(db, 'grading_curves'), {
      name: 'Standard Bell Curve',
      type: 'bell',
      config: { targetMean: 75, stddev: 10 }
    }).catch(e => handleFirestoreError(e, OperationType.CREATE, 'grading_curves'));
  };

  if (loading) {
    return (
      <div className="h-screen w-screen flex items-center justify-center bg-[#E4E3E0] font-mono">
        <div className="flex flex-col items-center gap-4">
          <BrainCircuit className="animate-pulse text-black" size={48} />
          <span className="text-xs uppercase tracking-widest animate-pulse">Initializing 1,000 Microservices...</span>
        </div>
      </div>
    );
  }

  if (!user) {
    return (
      <div className="h-screen w-screen flex items-center justify-center bg-[#E4E3E0] p-6">
        <div className="max-w-md w-full border border-black p-12 bg-white flex flex-col items-center gap-8 shadow-[12px_12px_0px_0px_rgba(0,0,0,1)]">
          <div className="flex flex-col items-center gap-2">
            <div className="bg-black p-4 text-white">
              <BrainCircuit size={40} />
            </div>
            <h1 className="text-2xl font-mono tracking-tighter uppercase mt-4">Child 360° Insight</h1>
            <p className="text-[10px] font-mono text-gray-400 uppercase tracking-widest text-center">Polyglot Microservices Ecosystem</p>
          </div>
          <button 
            onClick={handleLogin}
            disabled={isLoggingIn}
            className="w-full flex items-center justify-center gap-3 border border-black p-4 font-mono text-xs uppercase tracking-widest hover:bg-black hover:text-white transition-all active:translate-y-1 disabled:opacity-50"
          >
            <LogIn size={16} />
            {isLoggingIn ? 'Authenticating...' : 'Authenticate Guardian'}
          </button>
          
          {authError && (
            <motion.div 
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              className="w-full p-3 border border-red-500 bg-red-50 flex items-start gap-3"
            >
              <AlertCircle size={14} className="text-red-600 mt-0.5 shrink-0" />
              <span className="text-[10px] font-mono text-red-600 uppercase leading-tight">{authError}</span>
            </motion.div>
          )}
          <div className="grid grid-cols-2 gap-4 w-full opacity-20">
            <div className="h-1 bg-black" />
            <div className="h-1 bg-black" />
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="h-screen flex bg-[#E4E3E0] text-black overflow-hidden selection:bg-black selection:text-white">
      {/* Sidebar */}
      <aside className="w-64 border-r border-black flex flex-col bg-white">
        <div className="p-6 border-b border-black flex items-center gap-3">
          <div className="bg-black p-2 text-white">
            <BrainCircuit size={20} />
          </div>
          <div className="flex flex-col">
            <span className="text-xs font-mono font-bold tracking-tight uppercase leading-none">Child 360°</span>
            <span className="text-[9px] font-mono text-gray-400 uppercase tracking-tighter">Insight Platform</span>
          </div>
        </div>

        <nav className="flex-1 overflow-y-auto py-4">
          <div className="px-6 mb-4">
            <span className="text-[9px] font-mono text-gray-400 uppercase tracking-widest">Core Domains</span>
          </div>
          <SidebarItem 
            icon={LayoutDashboard} 
            label="Dashboard" 
            active={activeTab === 'dashboard'} 
            onClick={() => { setActiveTab('dashboard'); setSelectedChild(null); }} 
            language="Java"
          />
          <SidebarItem 
            icon={Users} 
            label="Family Registry" 
            active={activeTab === 'family'} 
            onClick={() => setActiveTab('family')} 
            language="Kotlin"
          />
          <SidebarItem 
            icon={GraduationCap} 
            label="Academic Engine" 
            active={activeTab === 'academic'} 
            onClick={() => setActiveTab('academic')} 
            language="Go"
          />
          <SidebarItem 
            icon={TrendingUp} 
            label="Grading Engine" 
            active={activeTab === 'grading'} 
            onClick={() => setActiveTab('grading')} 
            language="Go"
          />
          <SidebarItem 
            icon={Activity} 
            label="Health Tracker" 
            active={activeTab === 'health'} 
            onClick={() => setActiveTab('health')} 
            language="Rust"
          />
          <SidebarItem 
            icon={Microscope} 
            label="Analytics Lab" 
            active={activeTab === 'analytics'} 
            onClick={() => setActiveTab('analytics')} 
            language="Python"
          />

          <div className="px-6 mt-8 mb-4">
            <span className="text-[9px] font-mono text-gray-400 uppercase tracking-widest">Infrastructure</span>
          </div>
          <SidebarItem icon={Database} label="Data Lake" onClick={() => {}} language="Scala" />
          <SidebarItem icon={Terminal} label="Log Aggregator" onClick={() => {}} language="Elixir" />
          <SidebarItem icon={Cpu} label="1000th Service" onClick={() => {}} language="Malbolge" />
        </nav>

        <div className="p-4 border-t border-black bg-gray-50">
          <div className="flex items-center gap-3 mb-4">
            <img src={user.photoURL || ''} className="w-8 h-8 border border-black" alt="User" />
            <div className="flex flex-col overflow-hidden">
              <span className="text-[10px] font-mono font-bold truncate uppercase">{user.displayName}</span>
              <span className="text-[8px] font-mono text-gray-400 truncate">{user.email}</span>
            </div>
          </div>
          <button 
            onClick={handleLogout}
            className="w-full flex items-center justify-center gap-2 p-2 border border-black text-[10px] font-mono uppercase tracking-widest hover:bg-black hover:text-white transition-all"
          >
            <LogOut size={12} />
            Terminate Session
          </button>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 flex flex-col overflow-hidden">
        {/* Header */}
        <header className="h-16 border-b border-black bg-white flex items-center justify-between px-8">
          <div className="flex items-center gap-4">
            <span className="text-[10px] font-mono text-gray-400 uppercase tracking-widest">Current Context:</span>
            <span className="text-xs font-mono uppercase font-bold">
              {selectedChild ? `Child Profile / ${selectedChild.name}` : activeTab.replace('-', ' ')}
            </span>
          </div>
          <div className="flex items-center gap-6">
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse" />
              <span className="text-[10px] font-mono uppercase">Mesh Active</span>
            </div>
            <div className="h-4 w-px bg-gray-200" />
            <span className="text-[10px] font-mono text-gray-400">v4.2.0-stable</span>
          </div>
        </header>

        {/* View Content */}
        <div className="flex-1 overflow-y-auto p-8">
          <AnimatePresence mode="wait">
            {activeTab === 'dashboard' && !selectedChild && (
              <motion.div 
                key="dashboard"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                className="flex flex-col gap-8"
              >
                <div className="grid grid-cols-4 gap-6">
                  <StatCard label="Total Children" value={children.length} icon={Users} />
                  <StatCard label="Avg. Academic Score" value="84.2%" icon={GraduationCap} trend="2.4%" />
                  <StatCard label="Health Alerts" value="0" icon={AlertCircle} />
                  <StatCard label="Active Services" value="1,000" icon={Cpu} />
                </div>

                <div className="grid grid-cols-3 gap-8">
                  <div className="col-span-2 border border-black bg-white p-6">
                    <div className="flex justify-between items-center mb-6">
                      <h3 className="text-xs font-mono uppercase font-bold tracking-widest">Children Profiles</h3>
                      <div className="flex gap-2">
                        <button 
                          onClick={seedData}
                          className="text-[10px] font-mono uppercase border border-black px-3 py-1 hover:bg-black hover:text-white transition-all"
                        >
                          Seed Demo Data
                        </button>
                        <button className="text-[10px] font-mono uppercase border border-black px-3 py-1 hover:bg-black hover:text-white transition-all">Add New Child</button>
                      </div>
                    </div>
                    <div className="flex flex-col border-t border-black">
                      {children.map(child => (
                        <div 
                          key={child.id} 
                          onClick={() => setSelectedChild(child)}
                          className="flex items-center justify-between p-4 border-b border-black hover:bg-gray-50 cursor-pointer group"
                        >
                          <div className="flex items-center gap-4">
                            <div className="w-10 h-10 bg-gray-100 border border-black flex items-center justify-center font-mono text-lg uppercase">
                              {child.name.charAt(0)}
                            </div>
                            <div className="flex flex-col">
                              <span className="text-xs font-mono font-bold uppercase">{child.name}</span>
                              <span className="text-[10px] font-mono text-gray-400 uppercase">DOB: {child.dob}</span>
                            </div>
                          </div>
                          <div className="flex items-center gap-8">
                            <div className="flex flex-col items-end">
                              <span className="text-[10px] font-mono text-gray-400 uppercase">Last Exam</span>
                              <span className="text-xs font-mono">92/100</span>
                            </div>
                            <ChevronRight size={16} className="text-gray-300 group-hover:text-black transition-colors" />
                          </div>
                        </div>
                      ))}
                      {children.length === 0 && (
                        <div className="p-12 text-center text-gray-400 font-mono text-[10px] uppercase">No children registered in family unit.</div>
                      )}
                    </div>
                  </div>

                  <div className="border border-black bg-white p-6">
                    <h3 className="text-xs font-mono uppercase font-bold tracking-widest mb-6">Service Mesh Health</h3>
                    <div className="flex flex-col gap-2">
                      <ServiceStatus name="Family-Registry" language="Java" status="UP" />
                      <ServiceStatus name="Guardian-Auth" language="Kotlin" status="UP" />
                      <ServiceStatus name="Marks-Ingestor" language="Go" status="UP" />
                      <ServiceStatus name="Growth-Tracker" language="Rust" status="UP" />
                      <ServiceStatus name="Performance-Predictor" language="Python" status="UP" />
                      <ServiceStatus name="The-Everything-Saver" language="Malbolge" status="UP" />
                      <div className="mt-4 p-3 bg-gray-50 border border-dashed border-gray-300 text-center">
                        <span className="text-[9px] font-mono text-gray-400 uppercase">+ 994 services active</span>
                      </div>
                    </div>
                  </div>
                </div>
              </motion.div>
            )}

            {selectedChild && (
              <motion.div 
                key="child-details"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="flex flex-col gap-8"
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-6">
                    <button 
                      onClick={() => setSelectedChild(null)}
                      className="p-2 border border-black hover:bg-black hover:text-white transition-all"
                    >
                      <ChevronRight size={16} className="rotate-180" />
                    </button>
                    <div className="flex flex-col">
                      <h2 className="text-2xl font-mono tracking-tighter uppercase">{selectedChild.name}</h2>
                      <span className="text-[10px] font-mono text-gray-400 uppercase tracking-widest">Profile ID: {selectedChild.id}</span>
                    </div>
                  </div>
                  <div className="flex gap-4">
                    <button 
                      onClick={generateAIInsight}
                      disabled={isGenerating}
                      className="flex items-center gap-2 border border-black px-4 py-2 font-mono text-[10px] uppercase tracking-widest hover:bg-black hover:text-white transition-all disabled:opacity-50"
                    >
                      <BrainCircuit size={14} className={isGenerating ? 'animate-spin' : ''} />
                      {isGenerating ? 'Analyzing...' : 'Generate AI Insight'}
                    </button>
                    <button className="flex items-center gap-2 bg-black text-white px-4 py-2 font-mono text-[10px] uppercase tracking-widest hover:bg-gray-800 transition-all">
                      <Plus size={14} />
                      Log Record
                    </button>
                  </div>
                </div>

                <div className="grid grid-cols-3 gap-8">
                  <div className="col-span-2 flex flex-col gap-8">
                    {/* Academic Trend */}
                    <div className="border border-black bg-white p-6">
                      <div className="flex items-center gap-2 mb-6">
                        <GraduationCap size={16} />
                        <h3 className="text-xs font-mono uppercase font-bold tracking-widest">Academic Performance Trend</h3>
                      </div>
                      <div className="h-64 w-full">
                        <ResponsiveContainer width="100%" height="100%">
                          <AreaChart data={marks}>
                            <defs>
                              <linearGradient id="colorScore" x1="0" y1="0" x2="0" y2="1">
                                <stop offset="5%" stopColor="#000" stopOpacity={0.1}/>
                                <stop offset="95%" stopColor="#000" stopOpacity={0}/>
                              </linearGradient>
                            </defs>
                            <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#eee" />
                            <XAxis 
                              dataKey="date" 
                              tick={{ fontSize: 10, fontFamily: 'monospace' }} 
                              tickFormatter={(val) => new Date(val).toLocaleDateString()}
                            />
                            <YAxis tick={{ fontSize: 10, fontFamily: 'monospace' }} domain={[0, 100]} />
                            <Tooltip 
                              contentStyle={{ fontFamily: 'monospace', fontSize: '10px', border: '1px solid black', borderRadius: '0' }}
                            />
                            <Area type="monotone" dataKey="score" stroke="#000" fillOpacity={1} fill="url(#colorScore)" />
                          </AreaChart>
                        </ResponsiveContainer>
                      </div>
                    </div>

                    {/* Health Trend */}
                    <div className="border border-black bg-white p-6">
                      <div className="flex items-center gap-2 mb-6">
                        <Heart size={16} />
                        <h3 className="text-xs font-mono uppercase font-bold tracking-widest">Health Metrics (BMI)</h3>
                      </div>
                      <div className="h-64 w-full">
                        <ResponsiveContainer width="100%" height="100%">
                          <LineChart data={health}>
                            <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#eee" />
                            <XAxis 
                              dataKey="date" 
                              tick={{ fontSize: 10, fontFamily: 'monospace' }} 
                              tickFormatter={(val) => new Date(val).toLocaleDateString()}
                            />
                            <YAxis tick={{ fontSize: 10, fontFamily: 'monospace' }} />
                            <Tooltip 
                              contentStyle={{ fontFamily: 'monospace', fontSize: '10px', border: '1px solid black', borderRadius: '0' }}
                            />
                            <Line type="stepAfter" dataKey="weight" stroke="#000" strokeWidth={2} dot={{ r: 4, fill: '#000' }} />
                          </LineChart>
                        </ResponsiveContainer>
                      </div>
                    </div>
                  </div>

                  <div className="flex flex-col gap-8">
                    {/* Insights Panel */}
                    <div className="border border-black bg-white flex-1 flex flex-col">
                      <div className="p-4 border-b border-black bg-gray-50 flex items-center gap-2">
                        <BrainCircuit size={16} />
                        <h3 className="text-xs font-mono uppercase font-bold tracking-widest">AI Insights Lab</h3>
                      </div>
                      <div className="flex-1 overflow-y-auto p-6 flex flex-col gap-6">
                        {insights.map(insight => (
                          <div key={insight.id} className="border-l-2 border-black pl-4 py-2">
                            <div className="flex justify-between items-center mb-2">
                              <span className="text-[9px] font-mono uppercase bg-black text-white px-2 py-0.5">{insight.type}</span>
                              <span className="text-[9px] font-mono text-gray-400">{new Date(insight.date).toLocaleDateString()}</span>
                            </div>
                            <div className="text-[11px] font-mono leading-relaxed prose prose-sm max-w-none">
                              <ReactMarkdown>{insight.content}</ReactMarkdown>
                            </div>
                          </div>
                        ))}
                        {insights.length === 0 && (
                          <div className="flex-1 flex flex-col items-center justify-center text-center opacity-30 gap-4">
                            <Microscope size={32} />
                            <span className="text-[10px] font-mono uppercase">No insights generated yet.</span>
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              </motion.div>
            )}
            {activeTab === 'grading' && (
              <motion.div 
                key="grading"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                className="flex flex-col gap-8"
              >
                <div className="flex justify-between items-center">
                  <h2 className="text-2xl font-mono tracking-tighter uppercase">Grading Engine Configuration</h2>
                  <button 
                    onClick={async () => {
                      await addDoc(collection(db, 'grading_curves'), {
                        name: 'New Grading Curve',
                        type: 'fixed',
                        config: { thresholds: { 'A': 90, 'B': 80, 'C': 70, 'D': 60, 'F': 0 } }
                      }).catch(e => handleFirestoreError(e, OperationType.CREATE, 'grading_curves'));
                    }}
                    className="flex items-center gap-2 bg-black text-white px-4 py-2 font-mono text-[10px] uppercase tracking-widest hover:bg-gray-800 transition-all"
                  >
                    <Plus size={14} />
                    Create New Curve
                  </button>
                </div>

                <div className="grid grid-cols-2 gap-8">
                  {gradingCurves.map(curve => (
                    <div key={curve.id} className="border border-black bg-white p-6">
                      <div className="flex justify-between items-start mb-4">
                        <div className="flex flex-col">
                          <span className="text-xs font-mono font-bold uppercase">{curve.name}</span>
                          <span className="text-[10px] font-mono text-gray-400 uppercase">{curve.type} algorithm</span>
                        </div>
                        <div className="bg-black text-white text-[8px] px-2 py-1 uppercase font-mono">Active</div>
                      </div>
                      <div className="bg-gray-50 p-4 border border-gray-200 font-mono text-[10px] mb-4">
                        <pre>{JSON.stringify(curve.config, null, 2)}</pre>
                      </div>
                      <div className="flex gap-2">
                        <button 
                          onClick={() => setEditingCurve(curve)}
                          className="flex-1 border border-black p-2 text-[10px] font-mono uppercase tracking-widest hover:bg-black hover:text-white transition-all"
                        >
                          Edit Config
                        </button>
                        <button className="flex-1 border border-black p-2 text-[10px] font-mono uppercase tracking-widest hover:bg-black hover:text-white transition-all">Apply to Exam</button>
                      </div>
                    </div>
                  ))}
                  {gradingCurves.length === 0 && (
                    <div className="col-span-2 p-12 border border-dashed border-gray-300 text-center text-gray-400 font-mono text-[10px] uppercase">
                      No grading curves configured.
                    </div>
                  )}
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </main>

      {editingCurve && (
        <GradingCurveModal 
          curve={editingCurve} 
          onSave={saveCurve} 
          onCancel={() => setEditingCurve(null)} 
        />
      )}
    </div>
  );
}
